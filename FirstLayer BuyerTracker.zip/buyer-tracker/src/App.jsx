import { useState, useEffect } from "react";

// ─── STORAGE (localStorage for deployed app) ───────────────────────────────
const STORAGE_KEY = "firstlayer_buyers_v1";
const NOTES_KEY   = "firstlayer_notes_v1";

function loadBuyers() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); } catch { return []; }
}
function saveBuyers(buyers) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(buyers)); } catch {}
}
function loadNotes() {
  try { return JSON.parse(localStorage.getItem(NOTES_KEY) || "{}"); } catch { return {}; }
}
function saveNotes(notes) {
  try { localStorage.setItem(NOTES_KEY, JSON.stringify(notes)); } catch {}
}

// ─── CONSTANTS ─────────────────────────────────────────────────────────────
const PHASES = [
  { id: 1, label: "Initial Contact",       color: "#6366f1", light: "#eef2ff", icon: "📬" },
  { id: 2, label: "Email Sent",            color: "#8b5cf6", light: "#f5f3ff", icon: "✉️"  },
  { id: 3, label: "Text Follow-Up",        color: "#ec4899", light: "#fdf2f8", icon: "💬" },
  { id: 4, label: "Waiting for Response",  color: "#f59e0b", light: "#fffbeb", icon: "⏳" },
  { id: 5, label: "Appt. Scheduled",       color: "#10b981", light: "#ecfdf5", icon: "📅" },
  { id: 6, label: "Met with Client",       color: "#14b8a6", light: "#f0fdfa", icon: "🤝" },
  { id: 7, label: "Active Buyer",          color: "#3b82f6", light: "#eff6ff", icon: "🔑" },
  { id: 8, label: "Closed",               color: "#1B2A4A", light: "#f0f4ff", icon: "🏠" },
];

const TIMELINES = ["0–3 months","3–6 months","6–12 months","1–2 years","Just exploring"];

const EMAIL_TEMPLATES = [
  {
    label: "Initial Welcome",
    subject: "Welcome to Your Home Buying Journey — The FirstLayer Realty Team",
    body: `Hi [First Name],

Thank you for connecting with The FirstLayer Realty Team! We're excited to help you on your path to homeownership in the DFW area.

As your next step, I'd love to schedule a quick 15-minute call to learn more about what you're looking for.

Feel free to reply here or call/text me directly.

Looking forward to working with you!

Warm regards,
The FirstLayer Realty Team
MLW Realty Partners LLC | JPAR Realtors`,
  },
  {
    label: "Follow-Up Check-In",
    subject: "Checking In — Your Home Search",
    body: `Hi [First Name],

Just wanted to check in and see how things are going! The DFW market is moving quickly, and I want to make sure we're keeping you updated on the best opportunities.

Have there been any changes to your timeline or criteria? I'm here whenever you're ready to take the next step.

Best,
The FirstLayer Realty Team`,
  },
  {
    label: "Appointment Reminder",
    subject: "Reminder: Your Consultation is Coming Up!",
    body: `Hi [First Name],

Just a friendly reminder about your upcoming consultation! I'm looking forward to sitting down with you and mapping out your homebuying game plan.

Please don't hesitate to reach out if you have any questions before we meet.

See you soon!
The FirstLayer Realty Team`,
  },
];

const AGENT_EMAIL    = "agent@firstlayer.com";
const AGENT_PASSWORD = "firstlayer2024";

function genId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }

function formatDate(str) {
  if (!str) return "—";
  return new Date(str).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

function daysSince(str) {
  if (!str) return null;
  const days = Math.floor((Date.now() - new Date(str).getTime()) / 86400000);
  if (days === 0) return "Today";
  if (days === 1) return "Yesterday";
  return `${days}d ago`;
}

function isStale(str) {
  if (!str) return false;
  return (Date.now() - new Date(str).getTime()) > 7 * 86400000;
}

// ─── GLOBAL STYLES ─────────────────────────────────────────────────────────
const GLOBAL_CSS = `
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;0,9..40,800;1,9..40,400&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'DM Sans', -apple-system, sans-serif; -webkit-font-smoothing: antialiased; }
  @keyframes slideUp   { from { opacity:0; transform:translateY(20px); } to { opacity:1; transform:translateY(0); } }
  @keyframes fadeIn    { from { opacity:0; } to { opacity:1; } }
  @keyframes spin      { to { transform: rotate(360deg); } }
  ::-webkit-scrollbar { width:6px; height:6px; }
  ::-webkit-scrollbar-track { background:#f1f5f9; }
  ::-webkit-scrollbar-thumb { background:#cbd5e1; border-radius:3px; }
  ::-webkit-scrollbar-thumb:hover { background:#94a3b8; }
  input:focus, select:focus, textarea:focus { border-color: #1B2A4A !important; outline: none; box-shadow: 0 0 0 3px #1B2A4A18; }
  button:active { transform: scale(0.97); }
`;

// ─── SMALL COMPONENTS ──────────────────────────────────────────────────────

function Badge({ phase }) {
  const ph = PHASES.find(p => p.id === phase) || PHASES[0];
  return (
    <span style={{
      background: ph.light, color: ph.color,
      border: `1px solid ${ph.color}35`, borderRadius: 20,
      padding: "3px 10px", fontSize: 11, fontWeight: 700,
      display: "inline-flex", alignItems: "center", gap: 4, whiteSpace: "nowrap",
    }}>
      {ph.icon} {ph.label}
    </span>
  );
}

function PreApprovedBadge({ value }) {
  const cfg = {
    "Yes":         { bg: "#dcfce7", color: "#16a34a" },
    "In Progress": { bg: "#fef3c7", color: "#b45309" },
    "No":          { bg: "#fee2e2", color: "#ef4444" },
  };
  const c = cfg[value] || cfg["No"];
  return (
    <span style={{ fontSize: 11, fontWeight: 700, padding: "3px 8px", borderRadius: 6, background: c.bg, color: c.color }}>
      {value || "No"}
    </span>
  );
}

function Spinner() {
  return <div style={{ width: 20, height: 20, border: "2px solid #ffffff40", borderTopColor: "#fff", borderRadius: "50%", animation: "spin 0.7s linear infinite", display: "inline-block" }} />;
}

// ─── MODAL ─────────────────────────────────────────────────────────────────
function Modal({ title, onClose, children, wide }) {
  useEffect(() => {
    const esc = e => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", esc);
    return () => document.removeEventListener("keydown", esc);
  }, [onClose]);

  return (
    <div
      onClick={e => e.target === e.currentTarget && onClose()}
      style={{
        position: "fixed", inset: 0, background: "#00000080", zIndex: 1000,
        display: "flex", alignItems: "center", justifyContent: "center",
        padding: 16, animation: "fadeIn 0.15s ease",
      }}
    >
      <div style={{
        background: "#fff", borderRadius: 20,
        width: "100%", maxWidth: wide ? 720 : 600,
        maxHeight: "92vh", overflow: "auto",
        boxShadow: "0 32px 100px #00000045",
        animation: "slideUp 0.2s ease",
      }}>
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "22px 28px 18px", borderBottom: "1px solid #f1f5f9", position: "sticky", top: 0, background: "#fff", zIndex: 1,
        }}>
          <h2 style={{ fontSize: 18, fontWeight: 800, color: "#1B2A4A", letterSpacing: "-0.02em" }}>{title}</h2>
          <button onClick={onClose} style={{
            background: "#f1f5f9", border: "none", borderRadius: 8, width: 32, height: 32,
            cursor: "pointer", fontSize: 16, color: "#64748b", fontWeight: 700,
          }}>✕</button>
        </div>
        <div style={{ padding: "24px 28px" }}>{children}</div>
      </div>
    </div>
  );
}

// ─── FORM FIELD ────────────────────────────────────────────────────────────
function Field({ label, value, onChange, type = "text", placeholder, required, options, half }) {
  const base = {
    width: "100%", padding: "10px 13px", borderRadius: 10,
    border: "1.5px solid #e2e8f0", fontSize: 14, color: "#0f172a",
    background: "#f8fafc", fontFamily: "inherit", transition: "border-color 0.15s, box-shadow 0.15s",
  };
  return (
    <div style={{ marginBottom: 14 }}>
      <label style={{ display: "block", fontSize: 11, fontWeight: 700, color: "#475569", marginBottom: 5, textTransform: "uppercase", letterSpacing: "0.05em" }}>
        {label}{required && <span style={{ color: "#ef4444" }}> *</span>}
      </label>
      {options ? (
        <select value={value} onChange={e => onChange(e.target.value)} style={base}>
          <option value="">Select…</option>
          {options.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
      ) : type === "textarea" ? (
        <textarea value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} rows={3}
          style={{ ...base, resize: "vertical" }} />
      ) : (
        <input type={type} value={value} onChange={e => onChange(e.target.value)}
          placeholder={placeholder} required={required} style={base} />
      )}
    </div>
  );
}

// ─── BUYER FORM ────────────────────────────────────────────────────────────
function BuyerForm({ initial, onSave, onCancel }) {
  const blank = { firstName:"", lastName:"", email:"", phone:"", budgetMin:"", budgetMax:"", locations:"", timeline:"", preApproved:"No", notes:"", phase:1, lastContact:"" };
  const [f, setF] = useState(initial ? { ...blank, ...initial } : blank);
  const set = k => v => setF(p => ({ ...p, [k]: v }));

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 16px" }}>
        <Field label="First Name" value={f.firstName} onChange={set("firstName")} required />
        <Field label="Last Name"  value={f.lastName}  onChange={set("lastName")}  required />
        <Field label="Email" type="email" value={f.email} onChange={set("email")} placeholder="buyer@email.com" />
        <Field label="Phone" type="tel"   value={f.phone} onChange={set("phone")} placeholder="(214) 555-0000" />
        <Field label="Budget Min" value={f.budgetMin} onChange={set("budgetMin")} placeholder="$150,000" />
        <Field label="Budget Max" value={f.budgetMax} onChange={set("budgetMax")} placeholder="$350,000" />
      </div>
      <Field label="Desired Location(s)" value={f.locations} onChange={set("locations")} placeholder="Dallas, Frisco, Plano, McKinney…" />
      <Field label="Timeline"     value={f.timeline}    onChange={set("timeline")}    options={TIMELINES} />
      <Field label="Pre-Approved?" value={f.preApproved} onChange={set("preApproved")} options={["Yes","No","In Progress"]} />
      <Field label="Last Contact Date" type="date" value={f.lastContact} onChange={set("lastContact")} />

      {/* Phase selector */}
      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: "#475569", marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.05em" }}>Phase</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
          {PHASES.map(ph => (
            <button key={ph.id} type="button" onClick={() => set("phase")(ph.id)} style={{
              padding: "6px 12px", borderRadius: 20, fontSize: 11, fontWeight: 700, cursor: "pointer",
              background: f.phase === ph.id ? ph.color : ph.light,
              color: f.phase === ph.id ? "#fff" : ph.color,
              border: `1.5px solid ${ph.color}50`, transition: "all 0.15s",
            }}>{ph.icon} {ph.label}</button>
          ))}
        </div>
      </div>

      <Field label="Notes" type="textarea" value={f.notes} onChange={set("notes")} placeholder="Any important details about this buyer…" />

      <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", paddingTop: 8, borderTop: "1px solid #f1f5f9" }}>
        <button type="button" onClick={onCancel} style={{ padding: "10px 20px", borderRadius: 10, border: "1.5px solid #e2e8f0", background: "#fff", cursor: "pointer", fontWeight: 600, color: "#64748b", fontSize: 14 }}>Cancel</button>
        <button type="button" onClick={() => {
          if (!f.firstName.trim() || !f.lastName.trim()) { alert("First and last name are required."); return; }
          onSave({ ...f, lastContact: f.lastContact || new Date().toISOString().slice(0,10) });
        }} style={{ padding: "10px 24px", borderRadius: 10, border: "none", background: "#1B2A4A", color: "#fff", cursor: "pointer", fontWeight: 800, fontSize: 14 }}>
          Save Buyer
        </button>
      </div>
    </div>
  );
}

// ─── BUYER PROFILE MODAL ───────────────────────────────────────────────────
function BuyerProfile({ buyer, notes, onClose, onEdit, onPhaseChange, onAddNote, onDelete }) {
  const [noteText,        setNoteText]        = useState("");
  const [showTemplates,   setShowTemplates]   = useState(false);
  const [openTemplate,    setOpenTemplate]    = useState(null);
  const [copied,          setCopied]          = useState(false);

  const ph = PHASES.find(p => p.id === buyer.phase) || PHASES[0];

  function copyText(text) {
    navigator.clipboard?.writeText(text).then(() => { setCopied(true); setTimeout(() => setCopied(false), 1800); });
  }

  function handleAddNote() {
    if (!noteText.trim()) return;
    onAddNote(buyer.id, noteText.trim());
    setNoteText("");
  }

  return (
    <Modal title={`${buyer.firstName} ${buyer.lastName}`} onClose={onClose} wide>
      {/* Phase switcher */}
      <div style={{ marginBottom: 22 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 10 }}>Move to Phase</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
          {PHASES.map(p => (
            <button key={p.id} onClick={() => onPhaseChange(buyer.id, p.id)} style={{
              padding: "5px 11px", borderRadius: 20, fontSize: 11, fontWeight: 700, cursor: "pointer",
              background: buyer.phase === p.id ? p.color : p.light,
              color:      buyer.phase === p.id ? "#fff"   : p.color,
              border: `1.5px solid ${p.color}50`, transition: "all 0.15s",
              boxShadow: buyer.phase === p.id ? `0 3px 10px ${p.color}40` : "none",
            }}>{p.icon} {p.label}</button>
          ))}
        </div>
      </div>

      {/* Info grid */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 20 }}>
        {[
          ["Email",        buyer.email || "—"],
          ["Phone",        buyer.phone || "—"],
          ["Pre-Approved", buyer.preApproved || "No"],
          ["Budget",       buyer.budgetMin && buyer.budgetMax ? `${buyer.budgetMin} – ${buyer.budgetMax}` : buyer.budgetMin || buyer.budgetMax || "—"],
          ["Timeline",     buyer.timeline || "—"],
          ["Locations",    buyer.locations || "—"],
          ["Last Contact", formatDate(buyer.lastContact)],
          ["Added",        formatDate(buyer.createdAt)],
          ["Days Since Contact", daysSince(buyer.lastContact) || "—"],
        ].map(([k, v]) => (
          <div key={k} style={{ background: "#f8fafc", borderRadius: 10, padding: "10px 14px" }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 3 }}>{k}</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#0f172a" }}>{v}</div>
          </div>
        ))}
      </div>

      {buyer.notes && (
        <div style={{ background: "#fffbeb", border: "1px solid #fde68a", borderRadius: 10, padding: "12px 16px", marginBottom: 20 }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: "#92400e", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 5 }}>Notes</div>
          <div style={{ fontSize: 13, color: "#374151", whiteSpace: "pre-wrap", lineHeight: 1.6 }}>{buyer.notes}</div>
        </div>
      )}

      {/* Activity log */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: "#1e293b", marginBottom: 10 }}>Activity Log</div>
        <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
          <input
            value={noteText} onChange={e => setNoteText(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleAddNote()}
            placeholder="Add a call note, update, or reminder…"
            style={{ flex: 1, padding: "10px 13px", borderRadius: 10, border: "1.5px solid #e2e8f0", fontSize: 13, fontFamily: "inherit", outline: "none" }}
          />
          <button onClick={handleAddNote} style={{ padding: "10px 18px", borderRadius: 10, background: "#1B2A4A", color: "#fff", border: "none", fontWeight: 700, cursor: "pointer", fontSize: 13, whiteSpace: "nowrap" }}>
            + Log
          </button>
        </div>
        <div style={{ maxHeight: 170, overflowY: "auto", display: "flex", flexDirection: "column", gap: 6 }}>
          {(notes[buyer.id] || []).length === 0 ? (
            <div style={{ color: "#94a3b8", fontSize: 13, padding: "10px 0" }}>No activity logged yet.</div>
          ) : (
            [...(notes[buyer.id] || [])].reverse().map((n, i) => (
              <div key={i} style={{ background: "#f8fafc", borderRadius: 8, padding: "9px 13px", fontSize: 13, display: "flex", gap: 10 }}>
                <span style={{ color: "#94a3b8", fontSize: 11, fontWeight: 600, whiteSpace: "nowrap", paddingTop: 1 }}>{formatDate(n.date)}</span>
                <span style={{ color: "#374151", lineHeight: 1.5 }}>{n.text}</span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Email templates */}
      <div style={{ marginBottom: 20 }}>
        <button onClick={() => setShowTemplates(s => !s)} style={{
          padding: "9px 16px", borderRadius: 10, border: "1.5px solid #e2e8f0",
          background: showTemplates ? "#f1f5f9" : "#fff", cursor: "pointer", fontWeight: 600, fontSize: 13, color: "#374151",
          display: "flex", alignItems: "center", gap: 6,
        }}>
          📧 Email Templates <span style={{ fontSize: 10, color: "#94a3b8" }}>{showTemplates ? "▲" : "▼"}</span>
        </button>
        {showTemplates && (
          <div style={{ marginTop: 10, border: "1.5px solid #e2e8f0", borderRadius: 12, overflow: "hidden" }}>
            {EMAIL_TEMPLATES.map((t, i) => (
              <div key={i} style={{ borderBottom: i < EMAIL_TEMPLATES.length - 1 ? "1px solid #f1f5f9" : "none" }}>
                <button onClick={() => setOpenTemplate(openTemplate === i ? null : i)} style={{
                  width: "100%", textAlign: "left", padding: "13px 16px",
                  background: openTemplate === i ? "#f8fafc" : "none", border: "none",
                  cursor: "pointer", fontSize: 13, fontWeight: 700, color: "#1B2A4A",
                  display: "flex", alignItems: "center", gap: 8,
                }}>
                  <span style={{ fontSize: 12, color: "#94a3b8" }}>{openTemplate === i ? "▼" : "▶"}</span>
                  {t.label}
                </button>
                {openTemplate === i && (
                  <div style={{ padding: "4px 16px 16px" }}>
                    <div style={{ fontSize: 10, fontWeight: 700, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 4 }}>Subject</div>
                    <div style={{ fontSize: 13, color: "#374151", background: "#f8fafc", borderRadius: 8, padding: "9px 12px", marginBottom: 12 }}>
                      {t.subject.replace(/\[First Name\]/g, buyer.firstName)}
                    </div>
                    <div style={{ fontSize: 10, fontWeight: 700, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 4 }}>Body</div>
                    <pre style={{ fontSize: 12, color: "#374151", background: "#f8fafc", borderRadius: 8, padding: "12px 14px", whiteSpace: "pre-wrap", fontFamily: "inherit", margin: 0, lineHeight: 1.6 }}>
                      {t.body.replace(/\[First Name\]/g, buyer.firstName)}
                    </pre>
                    <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                      <button onClick={() => copyText(t.body.replace(/\[First Name\]/g, buyer.firstName))} style={{
                        padding: "7px 14px", borderRadius: 8, background: copied ? "#10b981" : "#1B2A4A",
                        color: "#fff", border: "none", cursor: "pointer", fontSize: 12, fontWeight: 700, transition: "background 0.2s",
                      }}>{copied ? "✓ Copied!" : "Copy Body"}</button>
                      <button onClick={() => copyText(t.subject.replace(/\[First Name\]/g, buyer.firstName))} style={{
                        padding: "7px 14px", borderRadius: 8, background: "#f1f5f9", color: "#374151", border: "none", cursor: "pointer", fontSize: 12, fontWeight: 600,
                      }}>Copy Subject</button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Action buttons */}
      <div style={{ display: "flex", gap: 10, justifyContent: "space-between", paddingTop: 16, borderTop: "1px solid #f1f5f9" }}>
        <button onClick={() => { if (window.confirm("Remove this buyer?")) onDelete(buyer.id); }} style={{
          padding: "10px 16px", borderRadius: 10, border: "1.5px solid #fecaca", background: "#fff", color: "#ef4444", cursor: "pointer", fontWeight: 700, fontSize: 13,
        }}>🗑 Remove</button>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={() => onEdit(buyer)} style={{ padding: "10px 20px", borderRadius: 10, border: "1.5px solid #1B2A4A", background: "#fff", color: "#1B2A4A", cursor: "pointer", fontWeight: 700, fontSize: 13 }}>✏️ Edit</button>
          <button onClick={onClose} style={{ padding: "10px 20px", borderRadius: 10, border: "none", background: "#1B2A4A", color: "#fff", cursor: "pointer", fontWeight: 800, fontSize: 13 }}>Done</button>
        </div>
      </div>
    </Modal>
  );
}

// ─── AGENT DASHBOARD ───────────────────────────────────────────────────────
function AgentDashboard({ buyers, notes, setBuyers, setNotes, onLogout }) {
  const [search,      setSearch]      = useState("");
  const [filterPhase, setFilterPhase] = useState(null);
  const [sortBy,      setSortBy]      = useState("name");
  const [showAdd,     setShowAdd]     = useState(false);
  const [editBuyer,   setEditBuyer]   = useState(null);
  const [viewBuyer,   setViewBuyer]   = useState(null);

  // Derived
  const phaseCounts = PHASES.map(ph => ({ ...ph, count: buyers.filter(b => b.phase === ph.id).length }));
  const totalClosed = buyers.filter(b => b.phase === 8).length;
  const needFollowUp = buyers.filter(b => b.phase !== 8 && isStale(b.lastContact)).length;

  const filtered = buyers
    .filter(b => {
      const name = `${b.firstName} ${b.lastName}`.toLowerCase();
      const matchSearch = !search || name.includes(search.toLowerCase()) || (b.email||"").toLowerCase().includes(search.toLowerCase()) || (b.phone||"").includes(search);
      const matchPhase = !filterPhase || b.phase === filterPhase;
      return matchSearch && matchPhase;
    })
    .sort((a, b) => {
      if (sortBy === "name")    return `${a.firstName}${a.lastName}`.localeCompare(`${b.firstName}${b.lastName}`);
      if (sortBy === "phase")   return a.phase - b.phase;
      if (sortBy === "contact") return (b.lastContact||"").localeCompare(a.lastContact||"");
      if (sortBy === "added")   return (b.createdAt||"").localeCompare(a.createdAt||"");
      return 0;
    });

  function addBuyer(data) {
    const nb = { ...data, id: genId(), createdAt: new Date().toISOString().slice(0,10) };
    const updated = [...buyers, nb];
    setBuyers(updated); saveBuyers(updated); setShowAdd(false);
  }
  function updateBuyer(data) {
    const updated = buyers.map(b => b.id === data.id ? { ...data } : b);
    setBuyers(updated); saveBuyers(updated); setEditBuyer(null);
    if (viewBuyer?.id === data.id) setViewBuyer(data);
  }
  function phaseChange(id, phase) {
    const lc = new Date().toISOString().slice(0,10);
    const updated = buyers.map(b => b.id === id ? { ...b, phase, lastContact: lc } : b);
    setBuyers(updated); saveBuyers(updated);
    if (viewBuyer?.id === id) setViewBuyer(updated.find(b => b.id === id));
  }
  function addNote(buyerId, text) {
    const entry = { text, date: new Date().toISOString().slice(0,10) };
    const updatedNotes = { ...notes, [buyerId]: [...(notes[buyerId]||[]), entry] };
    setNotes(updatedNotes); saveNotes(updatedNotes);
    const updatedBuyers = buyers.map(b => b.id === buyerId ? { ...b, lastContact: entry.date } : b);
    setBuyers(updatedBuyers); saveBuyers(updatedBuyers);
  }
  function deleteBuyer(id) {
    const updated = buyers.filter(b => b.id !== id);
    setBuyers(updated); saveBuyers(updated); setViewBuyer(null);
  }

  return (
    <div style={{ minHeight: "100vh", background: "#f1f5f9" }}>

      {/* Top nav */}
      <div style={{ background: "#1B2A4A", padding: "0 24px", position: "sticky", top: 0, zIndex: 100, boxShadow: "0 2px 12px #00000025" }}>
        <div style={{ maxWidth: 1280, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", height: 60 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 34, height: 34, background: "#C9A84C", borderRadius: 9, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>🏠</div>
            <div>
              <div style={{ fontWeight: 800, fontSize: 15, color: "#fff", letterSpacing: "-0.02em", lineHeight: 1.1 }}>FirstLayer</div>
              <div style={{ fontSize: 10, color: "#94a3b8", letterSpacing: "0.04em" }}>BUYER TRACKER</div>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            {needFollowUp > 0 && (
              <div style={{ background: "#ef444420", border: "1px solid #ef444440", borderRadius: 8, padding: "5px 11px", fontSize: 12, fontWeight: 700, color: "#ef4444" }}>
                ⚠️ {needFollowUp} need follow-up
              </div>
            )}
            <button onClick={onLogout} style={{ padding: "7px 14px", borderRadius: 8, background: "transparent", border: "1px solid #ffffff30", color: "#94a3b8", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>
              Sign Out
            </button>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1280, margin: "0 auto", padding: "28px 24px" }}>

        {/* Page header */}
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 24, flexWrap: "wrap", gap: 12 }}>
          <div>
            <h1 style={{ fontSize: 28, fontWeight: 800, color: "#0f172a", letterSpacing: "-0.03em", margin: 0 }}>Buyer Pipeline</h1>
            <p style={{ color: "#64748b", margin: "6px 0 0", fontSize: 14 }}>
              {buyers.length} total · {totalClosed} closed · {needFollowUp} need follow-up
            </p>
          </div>
          <button onClick={() => setShowAdd(true)} style={{
            padding: "12px 22px", borderRadius: 12, background: "#C9A84C", color: "#1B2A4A",
            border: "none", fontWeight: 800, fontSize: 14, cursor: "pointer",
            boxShadow: "0 4px 16px #C9A84C45", display: "flex", alignItems: "center", gap: 6,
          }}>＋ Add Buyer</button>
        </div>

        {/* Phase stat cards */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10, marginBottom: 28 }}>
          {phaseCounts.map(ph => {
            const active = filterPhase === ph.id;
            return (
              <button key={ph.id} onClick={() => setFilterPhase(active ? null : ph.id)} style={{
                background: active ? ph.color : "#fff",
                border: `2px solid ${active ? ph.color : "#e2e8f0"}`,
                borderRadius: 14, padding: "14px 16px", cursor: "pointer", textAlign: "left",
                transition: "all 0.18s", boxShadow: active ? `0 6px 20px ${ph.color}45` : "0 1px 4px #0000000c",
              }}>
                <div style={{ fontSize: 20, marginBottom: 4 }}>{ph.icon}</div>
                <div style={{ fontSize: 30, fontWeight: 800, color: active ? "#fff" : ph.color, lineHeight: 1 }}>{ph.count}</div>
                <div style={{ fontSize: 11, color: active ? "#ffffffcc" : "#64748b", marginTop: 5, fontWeight: 600, lineHeight: 1.3 }}>{ph.label}</div>
              </button>
            );
          })}
        </div>

        {/* Search + sort bar */}
        <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap", alignItems: "center" }}>
          <div style={{ position: "relative", flex: 1, minWidth: 240 }}>
            <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", pointerEvents: "none", fontSize: 15 }}>🔍</span>
            <input
              value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search by name, email, or phone…"
              style={{ width: "100%", padding: "11px 13px 11px 38px", borderRadius: 11, border: "1.5px solid #e2e8f0", fontSize: 14, background: "#fff", outline: "none", fontFamily: "inherit" }}
            />
          </div>
          <select value={sortBy} onChange={e => setSortBy(e.target.value)} style={{ padding: "11px 13px", borderRadius: 11, border: "1.5px solid #e2e8f0", background: "#fff", fontSize: 13, fontFamily: "inherit", color: "#374151", outline: "none", cursor: "pointer" }}>
            <option value="name">Sort: Name</option>
            <option value="phase">Sort: Phase</option>
            <option value="contact">Sort: Last Contact</option>
            <option value="added">Sort: Date Added</option>
          </select>
          {filterPhase && (
            <button onClick={() => setFilterPhase(null)} style={{ padding: "9px 14px", borderRadius: 10, background: "#fee2e2", border: "none", color: "#ef4444", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>
              ✕ Clear Filter
            </button>
          )}
          <span style={{ fontSize: 13, color: "#64748b", whiteSpace: "nowrap" }}>{filtered.length} buyer{filtered.length !== 1 ? "s" : ""}</span>
        </div>

        {/* Buyer table */}
        <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #e2e8f0", overflow: "hidden", boxShadow: "0 2px 10px #0000000a" }}>

          {/* Table header */}
          <div style={{
            display: "grid", gridTemplateColumns: "2fr 1.6fr 1.1fr 0.9fr 0.9fr 1fr 90px",
            padding: "12px 20px", background: "#f8fafc", borderBottom: "1px solid #e2e8f0",
          }}>
            {["Buyer","Contact","Budget","Timeline","Pre-Approved","Last Contact",""].map(h => (
              <div key={h} style={{ fontSize: 10, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.06em" }}>{h}</div>
            ))}
          </div>

          {filtered.length === 0 ? (
            <div style={{ padding: "64px 24px", textAlign: "center" }}>
              <div style={{ fontSize: 44, marginBottom: 14 }}>🏡</div>
              <div style={{ fontSize: 17, fontWeight: 700, color: "#1e293b", marginBottom: 6 }}>No buyers found</div>
              <div style={{ fontSize: 14, color: "#94a3b8" }}>Add your first buyer or adjust your search filters.</div>
            </div>
          ) : (
            filtered.map((b, i) => {
              const stale = b.phase !== 8 && isStale(b.lastContact);
              return (
                <div key={b.id} style={{
                  display: "grid", gridTemplateColumns: "2fr 1.6fr 1.1fr 0.9fr 0.9fr 1fr 90px",
                  padding: "15px 20px", borderBottom: i < filtered.length - 1 ? "1px solid #f1f5f9" : "none",
                  alignItems: "center", transition: "background 0.1s",
                  background: stale ? "#fff5f5" : i % 2 === 0 ? "#fff" : "#fafafa",
                }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14, color: "#0f172a" }}>{b.firstName} {b.lastName}</div>
                    <div style={{ marginTop: 5 }}><Badge phase={b.phase} /></div>
                  </div>
                  <div>
                    <div style={{ fontSize: 13, color: "#374151" }}>{b.email || "—"}</div>
                    <div style={{ fontSize: 12, color: "#64748b", marginTop: 2 }}>{b.phone || "—"}</div>
                  </div>
                  <div style={{ fontSize: 13, color: "#374151" }}>
                    {b.budgetMin && b.budgetMax ? `${b.budgetMin}–${b.budgetMax}` : b.budgetMin || b.budgetMax || "—"}
                  </div>
                  <div style={{ fontSize: 13, color: "#374151" }}>{b.timeline || "—"}</div>
                  <div><PreApprovedBadge value={b.preApproved} /></div>
                  <div style={{ fontSize: 13, color: stale ? "#ef4444" : "#374151", fontWeight: stale ? 700 : 400 }}>
                    {daysSince(b.lastContact) || "—"}
                    {stale && <div style={{ fontSize: 10, color: "#ef4444" }}>⚠ Follow up!</div>}
                  </div>
                  <div style={{ display: "flex", gap: 6 }}>
                    <button onClick={() => setViewBuyer(b)} style={{ padding: "7px 13px", borderRadius: 8, background: "#1B2A4A", color: "#fff", border: "none", fontSize: 12, fontWeight: 700, cursor: "pointer" }}>View</button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        <div style={{ marginTop: 12, fontSize: 11, color: "#94a3b8", textAlign: "center" }}>
          Rows highlighted in red = 7+ days without contact · Click any phase card to filter
        </div>
      </div>

      {/* Modals */}
      {showAdd && (
        <Modal title="Add New Buyer" onClose={() => setShowAdd(false)}>
          <BuyerForm onSave={addBuyer} onCancel={() => setShowAdd(false)} />
        </Modal>
      )}
      {editBuyer && (
        <Modal title="Edit Buyer" onClose={() => setEditBuyer(null)}>
          <BuyerForm initial={editBuyer} onSave={updateBuyer} onCancel={() => setEditBuyer(null)} />
        </Modal>
      )}
      {viewBuyer && (
        <BuyerProfile
          buyer={buyers.find(b => b.id === viewBuyer.id) || viewBuyer}
          notes={notes}
          onClose={() => setViewBuyer(null)}
          onEdit={b => { setViewBuyer(null); setEditBuyer(b); }}
          onPhaseChange={phaseChange}
          onAddNote={addNote}
          onDelete={id => { deleteBuyer(id); setViewBuyer(null); }}
        />
      )}
    </div>
  );
}

// ─── BUYER PORTAL ──────────────────────────────────────────────────────────
function BuyerPortal({ buyer, onLogout }) {
  const ph     = PHASES.find(p => p.id === buyer.phase) || PHASES[0];
  const pct    = Math.round((buyer.phase / PHASES.length) * 100);

  const NEXT_STEPS = {
    1: ["Check your email for a welcome message from your agent","Gather your financial documents (pay stubs, tax returns, bank statements)","Think about your ideal neighborhoods and must-haves"],
    2: ["Reply to the email your agent sent you","Review the information and write down your questions","Research neighborhoods in DFW you'd like to explore"],
    3: ["Respond to your agent's text or call when convenient","Be ready to share your timeline and budget range","Ask about current DFW listings that match your criteria"],
    4: ["Your agent is waiting to hear from you — no pressure!","Reach out anytime for a quick 15-minute call","Consider sharing any updates on your timeline"],
    5: ["Your consultation is scheduled — you're on your way!","Prepare a list of questions for your agent","Research the neighborhoods you're most interested in"],
    6: ["Great progress — you've met with your agent!","Next: connect with a lender for pre-approval","Review any listings your agent has shared"],
    7: ["You're an active buyer — exciting times ahead!","Stay in close contact for new listings","Be ready to move quickly when the right home appears"],
    8: ["Congratulations — you're a homeowner! 🎉","Complete your final walkthrough checklist","Enjoy your new home in the DFW area!"],
  };

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(160deg, #0f172a 0%, #1B2A4A 40%, #2E4070 100%)", display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
      <div style={{ width: "100%", maxWidth: 500 }}>

        {/* Logo */}
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div style={{ width: 52, height: 52, background: "#C9A84C", borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, margin: "0 auto 12px" }}>🏠</div>
          <div style={{ fontWeight: 800, fontSize: 18, color: "#fff" }}>The FirstLayer Realty Team</div>
          <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 2 }}>MLW Realty Partners LLC | JPAR Realtors</div>
        </div>

        <div style={{ background: "#fff", borderRadius: 22, padding: "28px 28px 24px", boxShadow: "0 32px 100px #00000050" }}>
          <div style={{ color: "#64748b", fontSize: 13, marginBottom: 4 }}>Welcome back,</div>
          <h2 style={{ fontSize: 24, fontWeight: 800, color: "#0f172a", margin: "0 0 22px", letterSpacing: "-0.02em" }}>{buyer.firstName} {buyer.lastName} 👋</h2>

          {/* Progress */}
          <div style={{ marginBottom: 22 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, alignItems: "center" }}>
              <span style={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.05em" }}>Your Journey</span>
              <span style={{ fontSize: 12, fontWeight: 800, color: ph.color }}>{pct}% Complete</span>
            </div>
            <div style={{ height: 8, background: "#f1f5f9", borderRadius: 99, overflow: "hidden" }}>
              <div style={{ height: "100%", width: `${pct}%`, background: `linear-gradient(90deg, #C9A84C, ${ph.color})`, borderRadius: 99, transition: "width 0.8s ease" }} />
            </div>
          </div>

          {/* Current phase */}
          <div style={{ background: ph.light, border: `2px solid ${ph.color}30`, borderRadius: 14, padding: "18px", marginBottom: 20 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: ph.color, textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 5 }}>Current Status</div>
            <div style={{ fontSize: 20, fontWeight: 800, color: "#0f172a" }}>{ph.icon} {ph.label}</div>
          </div>

          {/* Stepper */}
          <div style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 12 }}>Your Path to Homeownership</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
              {PHASES.map(p => {
                const done    = p.id < buyer.phase;
                const current = p.id === buyer.phase;
                return (
                  <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <div style={{
                      width: 26, height: 26, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: done ? 12 : 11, flexShrink: 0,
                      background: done ? p.color : current ? p.color : "#f1f5f9",
                      color: done || current ? "#fff" : "#94a3b8", fontWeight: 800,
                    }}>
                      {done ? "✓" : p.icon}
                    </div>
                    <span style={{ fontSize: 13, fontWeight: current ? 700 : 400, color: current ? "#0f172a" : done ? "#64748b" : "#94a3b8" }}>
                      {p.label}
                    </span>
                    {current && (
                      <span style={{ fontSize: 10, background: p.color, color: "#fff", padding: "2px 8px", borderRadius: 99, fontWeight: 700, marginLeft: 2 }}>
                        YOU ARE HERE
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Next steps */}
          <div style={{ background: "#f8fafc", borderRadius: 12, padding: "16px", marginBottom: 20 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: "#374151", marginBottom: 12 }}>✅ Your Next Steps</div>
            {(NEXT_STEPS[buyer.phase] || []).map((step, i) => (
              <div key={i} style={{ display: "flex", gap: 9, marginBottom: 9, alignItems: "flex-start" }}>
                <div style={{ width: 20, height: 20, borderRadius: "50%", background: "#C9A84C", color: "#1B2A4A", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 800, flexShrink: 0, marginTop: 1 }}>{i+1}</div>
                <span style={{ fontSize: 13, color: "#374151", lineHeight: 1.5 }}>{step}</span>
              </div>
            ))}
          </div>

          {/* Contact card */}
          <div style={{ background: "#1B2A4A", borderRadius: 14, padding: "18px", textAlign: "center", marginBottom: 16 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: "#C9A84C", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 8 }}>Questions? We're Here</div>
            <div style={{ fontSize: 14, color: "#fff", fontWeight: 700 }}>The FirstLayer Realty Team</div>
            <div style={{ fontSize: 12, color: "#94a3b8", margin: "4px 0 14px" }}>ABR Certified | DFW Specialist</div>
            <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
              <a href="mailto:agent@firstlayer.com" style={{ padding: "9px 18px", background: "#C9A84C", color: "#1B2A4A", borderRadius: 9, textDecoration: "none", fontSize: 12, fontWeight: 800 }}>📧 Email Us</a>
              <a href="tel:+12145550000" style={{ padding: "9px 18px", background: "#ffffff15", color: "#fff", borderRadius: 9, textDecoration: "none", fontSize: 12, fontWeight: 700, border: "1px solid #ffffff20" }}>📞 Call Us</a>
            </div>
          </div>

          <button onClick={onLogout} style={{ width: "100%", padding: "10px", borderRadius: 10, border: "1.5px solid #e2e8f0", background: "#fff", color: "#94a3b8", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── LOGIN PAGE ────────────────────────────────────────────────────────────
function LoginPage({ buyers, onLogin }) {
  const [email,    setEmail]    = useState("");
  const [password, setPassword] = useState("");
  const [error,    setError]    = useState("");
  const [loading,  setLoading]  = useState(false);

  function handleLogin() {
    if (!email || !password) { setError("Please enter your email and password."); return; }
    setLoading(true); setError("");
    setTimeout(() => {
      // Agent login
      if (email.toLowerCase() === AGENT_EMAIL && password === AGENT_PASSWORD) {
        onLogin({ role: "agent" }); return;
      }
      // Buyer login (email + phone OR temp "buyer123")
      const buyer = buyers.find(b =>
        b.email?.toLowerCase() === email.toLowerCase() &&
        (b.phone === password || password === "buyer123")
      );
      if (buyer) { onLogin({ role: "buyer", buyer }); return; }
      setError("Invalid email or password. Please try again.");
      setLoading(false);
    }, 600);
  }

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(160deg, #0f172a 0%, #1B2A4A 40%, #2E4070 100%)", display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
      <div style={{ width: "100%", maxWidth: 400 }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ width: 60, height: 60, background: "#C9A84C", borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, margin: "0 auto 14px", boxShadow: "0 8px 28px #C9A84C50" }}>🏠</div>
          <h1 style={{ color: "#fff", fontWeight: 800, fontSize: 22, margin: "0 0 6px", letterSpacing: "-0.03em" }}>FirstLayer Realty</h1>
          <p style={{ color: "#64748b", margin: 0, fontSize: 13 }}>Buyer Tracker — Sign In</p>
        </div>

        <div style={{ background: "#fff", borderRadius: 22, padding: "32px", boxShadow: "0 32px 100px #00000050" }}>
          <Field label="Email Address" type="email" value={email} onChange={setEmail} placeholder="your@email.com" required />
          <Field label="Password"      type="password" value={password} onChange={setPassword} placeholder="••••••••" required />

          {error && (
            <div style={{ background: "#fee2e2", color: "#dc2626", borderRadius: 10, padding: "10px 14px", fontSize: 13, fontWeight: 600, marginBottom: 14, display: "flex", gap: 8, alignItems: "center" }}>
              ⚠️ {error}
            </div>
          )}

          <button
            onClick={handleLogin}
            onKeyDown={e => e.key === "Enter" && handleLogin()}
            disabled={loading}
            style={{ width: "100%", padding: "13px", borderRadius: 12, background: "#1B2A4A", color: "#fff", border: "none", fontWeight: 800, fontSize: 15, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, opacity: loading ? 0.8 : 1 }}
          >
            {loading ? <><Spinner /> Signing in…</> : "Sign In →"}
          </button>

          <div style={{ marginTop: 20, padding: "14px", background: "#f8fafc", borderRadius: 10 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 8 }}>Demo Credentials</div>
            <div style={{ fontSize: 12, color: "#475569", lineHeight: 1.8 }}>
              <strong>Agent:</strong> agent@firstlayer.com / firstlayer2024<br/>
              <strong>Buyer:</strong> buyer's email + phone number
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── ROOT APP ──────────────────────────────────────────────────────────────
export default function App() {
  const [session, setSession] = useState(null);
  const [buyers,  setBuyers]  = useState(() => loadBuyers());
  const [notes,   setNotes]   = useState(() => loadNotes());

  return (
    <>
      <style>{GLOBAL_CSS}</style>
      {!session ? (
        <LoginPage buyers={buyers} onLogin={setSession} />
      ) : session.role === "agent" ? (
        <AgentDashboard
          buyers={buyers} notes={notes}
          setBuyers={setBuyers} setNotes={setNotes}
          onLogout={() => setSession(null)}
        />
      ) : (
        <BuyerPortal buyer={session.buyer} onLogout={() => setSession(null)} />
      )}
    </>
  );
}
