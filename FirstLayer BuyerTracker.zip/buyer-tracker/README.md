# FirstLayer Buyer Tracker

A professional real estate buyer pipeline tracker built for **The FirstLayer Realty Team**.

## 🚀 Deploy to Vercel in 5 Minutes

### Option A — Deploy via GitHub (Recommended)

1. **Create a GitHub account** at github.com (free)
2. **Create a new repository** — click the "+" icon → "New repository"
   - Name it: `firstlayer-buyer-tracker`
   - Keep it Private
   - Click "Create repository"
3. **Upload your files** — drag and drop all files from this folder into GitHub
4. **Go to vercel.com** — sign up free with your GitHub account
5. Click **"Add New Project"** → Import your GitHub repo
6. Vercel auto-detects Vite — just click **"Deploy"**
7. ✅ You'll get a live URL like: `firstlayer-buyer-tracker.vercel.app`

### Option B — Deploy via Vercel CLI

```bash
# Install Node.js from nodejs.org first, then:
npm install -g vercel
cd firstlayer-buyer-tracker
npm install
vercel
# Follow the prompts — it's automatic
```

---

## 🔐 Login Credentials

| Role  | Email                     | Password        |
|-------|---------------------------|-----------------|
| Agent | agent@firstlayer.com      | firstlayer2024  |
| Buyer | (their email address)     | their phone number |

> **To change the agent password:** Open `src/App.jsx` and update the `AGENT_EMAIL` and `AGENT_PASSWORD` constants at the top.

---

## ✏️ How to Customize

### Change Agent Email/Password
In `src/App.jsx`, find these lines near the top:
```js
const AGENT_EMAIL    = "agent@firstlayer.com";
const AGENT_PASSWORD = "firstlayer2024";
```
Replace with your actual email and a strong password.

### Add/Edit Phases
Find the `PHASES` array in `src/App.jsx`:
```js
const PHASES = [
  { id: 1, label: "Initial Contact", color: "#6366f1", light: "#eef2ff", icon: "📬" },
  // add more here...
];
```

### Edit Email Templates
Find the `EMAIL_TEMPLATES` array and customize the subject and body text.

### Update Your Contact Info
Search for `agent@firstlayer.com` and `+12145550000` and replace with your real contact details.

---

## 📱 Features

- **Agent Dashboard** — Full buyer pipeline with phase stats, search, sort, follow-up alerts
- **Buyer Profiles** — Edit info, move phases, activity log, email templates
- **Buyer Portal** — Clean status page buyers can view with next steps
- **Persistent Storage** — All data saved in browser localStorage
- **Mobile Responsive** — Works on any device
- **Follow-up Alerts** — Rows turn red after 7 days without contact

---

## 🛠 Local Development

```bash
npm install
npm run dev
# Open http://localhost:5173
```

---

## 📦 Tech Stack

- React 18
- Vite 5
- No external UI library — pure CSS-in-JS
- localStorage for data persistence

---

Built for The FirstLayer Realty Team | MLW Realty Partners LLC | JPAR Realtors
